﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task07
{
    class myFunction
    {

    }


    class Program
    {
        static void Main()
        {
            Console.ReadKey();
        }
    }
}
