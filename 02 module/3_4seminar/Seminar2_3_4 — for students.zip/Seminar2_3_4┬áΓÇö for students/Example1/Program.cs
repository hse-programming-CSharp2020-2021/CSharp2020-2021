﻿using System;

// пример взят с сайта https://metanit.com/sharp/tutorial/3.1.php

namespace HelloApp
{
    class Person
    {
        public string name; // имя
        public int age;     // возраст

        public void GetInfo()
        {
            Console.WriteLine($"Имя: {name}  Возраст: {age}");
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Person tom;

            Console.ReadKey();
        }
    }
}