﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task05
{
    public class ConsolePlate
    {
        char _plateChar; // символ
        ConsoleColor _plateColor = ConsoleColor.White; // цвет символа
    }

    class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}
